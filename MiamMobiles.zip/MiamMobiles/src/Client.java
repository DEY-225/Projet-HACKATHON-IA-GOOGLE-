import java.util.List;
import java.util.ArrayList; // Important pour initialiser les listes si besoin

public class Client {
    // --- Champs existants et nouveaux ---
    private String nom;
    private String password; // <-- NOUVEAU : N�cessaire pour getPassword() dans AuthService
    private double latitude;
    private double longitude;
    private List<String> preferences; // Champ pour les pr�f�rences
    private boolean peutRecevoirNotif; // <-- NOUVEAU : Pour la gestion des notifications
    // Vous pourriez aussi ajouter un champ pour le suivi des envois de notifs,
    // par exemple private int nbNotificationsEnvoyees; ou un List<Date> pour un historique.

    // --- Constructeur mis � jour ---
    // Il est important d'inclure tous les champs pertinents dans le constructeur.
    public Client(String nom, String password, double latitude, double longitude, List<String> preferences, boolean peutRecevoirNotif) {
        this.nom = nom;
        this.password = password;
        this.latitude = latitude;
        this.longitude = longitude;
        // Si les pr�f�rences peuvent �tre nulles au d�part, initialisez-les � une ArrayList vide
        this.preferences = (preferences != null) ? preferences : new ArrayList<>();
        this.peutRecevoirNotif = peutRecevoirNotif;
    }

    // --- Getters existants ---
    public String getNom() {
        return this.nom;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    // --- NOUVELLES M�THODES (pour r�soudre les erreurs "cannot find symbol") ---

    // Pour AuthService.java:22
    public String getPassword() {
        return this.password;
    }

    // Pour NotificationEngine.java:30
    public boolean peutRecevoirNotif() {
        return this.peutRecevoirNotif; // Retourne la valeur du champ
    }

    // Pour NotificationEngine.java:35
    public void enregistrerEnvoiNotif() {
        // Logique pour enregistrer l'envoi d'une notification.
        // Vous pourriez par exemple :
        // - Incr�menter un compteur dans la classe Client (ex: this.nbNotificationsEnvoyees++;)
        // - Ajouter une entr�e dans une liste d'historique (ex: this.historiqueNotifs.add(new Date());)
        System.out.println("Notification enregistr�e pour le client " + this.nom);
    }

    // Pour PreferenceManager.java:16
    public boolean ajouterPreference(String motCleRecherche) {
        if (this.preferences == null) {
            this.preferences = new ArrayList<>(); // S'assurer que la liste est initialis�e
        }
        if (!this.preferences.contains(motCleRecherche)) { // �viter les doublons
            return this.preferences.add(motCleRecherche);
        }
        return false; // La pr�f�rence existait d�j�
    }

    // Le getter que vous aviez ajout� (tr�s bien !)
    public List<String> getPreferences() {
        return this.preferences;
    }

    // --- Setters si n�cessaire (pour modifier les champs apr�s la cr�ation) ---
    public void setPassword(String password) {
        this.password = password;
    }

    public void setPeutRecevoirNotif(boolean peutRecevoirNotif) {
        this.peutRecevoirNotif = peutRecevoirNotif;
    }

    public void setPreferences(List<String> preferences) {
        this.preferences = preferences;
    }

    // ... autres m�thodes de votre classe
}