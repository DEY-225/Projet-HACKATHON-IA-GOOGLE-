import java.util.List;

public class NotificationEngine {

    private static final double NOTE_MIN_POUR_PUB = 4.5;
    private static final double RAYON_PUB_KM = 1.5;

    public static void demarrer(List<Vendeuse> vendeuses, List<Client> clients) {
        System.out.println("\n--- [Moteur de Notification IA] D�marrage du scan ---");

        // 1. On cherche les vendeuses "Top" et "Ouvertes"
        for (Vendeuse vendeuse : vendeuses) {
            if (vendeuse.estOuverte() && vendeuse.getNote() >= NOTE_MIN_POUR_PUB) {
                System.out.println("\n[IA] Opportunit� d�tect�e: " + vendeuse.getNomCommerce() + " (Note: " + vendeuse.getNote() + ") est ouverte.");
                
                // On cherche maintenant les clients pertinents pour cette opportunit�
                chercherClientsCibles(vendeuse, clients);
            }
        }
    }

    private static void chercherClientsCibles(Vendeuse vendeuse, List<Client> clients) {
        String produitPhare = "Alloco"; // On simplifie, on suppose qu'on fait la pub pour l'Alloco

        for (Client client : clients) {
            // 2. On v�rifie les 3 conditions sur le client
            boolean aLaPreference = client.getPreferences().contains(produitPhare);
            double distance = AppTest.calculerDistance(client.getLatitude(), client.getLongitude(), vendeuse.getLatitude(), vendeuse.getLongitude());
            boolean estProche = distance <= RAYON_PUB_KM;
            boolean peutRecevoir = client.peutRecevoirNotif();

            if (aLaPreference && estProche && peutRecevoir) {
                // L'IA a pris sa d�cision ! On envoie.
                envoyerNotification(client, vendeuse, distance);
                client.enregistrerEnvoiNotif();
            }
        }
    }

    private static void envoyerNotification(Client client, Vendeuse vendeuse, double distance) {
        System.out.println("======================================================");
        System.out.println("||       ** NOTIFICATION ENVOY�E AU CLIENT **       ||");
        System.out.printf("|| Bonjour ! Une super opportunit� pr�s de vous :   ||\n");
        System.out.printf("|| %s (not�e %.1f/5) est ouverte � seulement %.0f m !||\n", vendeuse.getNomCommerce(), vendeuse.getNote(), distance * 1000);
        System.out.println("======================================================");
    }
}