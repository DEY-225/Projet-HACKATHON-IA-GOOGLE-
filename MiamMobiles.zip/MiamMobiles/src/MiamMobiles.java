/**
 * @(#)MiamMobiles.java
 *
 * MiamMobiles application
 *
 * @author 
 * @version 1.00 2025/7/20
 */
 
public class MiamMobiles {
    
    public static void main(String[] args) {
    	
    	// TODO, add your application code
    	System.out.println("Hello World!");
    }
}
